'''
py-bluerecording
'''

__version__ = "0.1.0"
